import { Component } from '@angular/core';

@Component({
  selector: 'app-personalised-showcase',
  templateUrl: './personalised-showcase.component.html',
  styleUrl: './personalised-showcase.component.css'
})
export class PersonalisedShowcaseComponent {

}
