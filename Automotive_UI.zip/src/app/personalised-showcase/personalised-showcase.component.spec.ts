import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PersonalisedShowcaseComponent } from './personalised-showcase.component';

describe('PersonalisedShowcaseComponent', () => {
  let component: PersonalisedShowcaseComponent;
  let fixture: ComponentFixture<PersonalisedShowcaseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PersonalisedShowcaseComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(PersonalisedShowcaseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
