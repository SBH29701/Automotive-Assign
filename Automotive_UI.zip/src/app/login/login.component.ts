import { Component } from '@angular/core';
import { AuthService } from  './auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
// Properties to bind to the login form
username: string = '';
password: string = '';

constructor(private authService: AuthService) { }

login(): void {
  // Call AuthService to perform authentication
  this.authService.login(this.username, this.password)
    .subscribe(response => {
      // Handle successful login, redirect based on role
    }, error => {
      // Handle authentication error
    });
}
}
