import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vehicle-display',
  templateUrl: './vehicle-display.component.html',
  styleUrl: './vehicle-display.component.css'
})
export class VehicleDisplayComponent implements OnInit {
    constructor(public vehicleService : any) {}
    
    ngOnInit() {
        this.getVehicles();
    }

    // getVehicles(): void{
    //   console.log("Getting vehicles...");
    //   this.vehicleService.getVehicles().subscribe(
    //       data => {this.handleData(data)},
    //       error => {console.log('Error getting vehicles')}
    //   );
    // };

    // handleData(data):void { 
}
