import { Component } from '@angular/core';

@Component({
  selector: 'app-purchase-process',
  templateUrl: './purchase-process.component.html',
  styleUrl: './purchase-process.component.css'
})
export class PurchaseProcessComponent {

}
