import { Injectable, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})

export class AuthService implements OnInit{
  private apiUrl = 'http://your-backend-api-url';

  constructor(private http: HttpClient) { }
  ngOnInit(): void {
    
  }

  login(username: string, password: string): Observable<any> {
    // Implement login logic and call backend API
    // Use HttpClient for making HTTP requests
    const credentials = { username, password };
    return this.http.post(`${this.apiUrl}/login`, credentials);
  }
}