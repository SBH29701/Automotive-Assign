import { Component } from '@angular/core';

@Component({
  selector: 'app-inventry-management',
  templateUrl: './inventry-management.component.html',
  styleUrl: './inventry-management.component.css'
})
export class InventryManagementComponent {

}
