import { Component } from '@angular/core';

@Component({
  selector: 'app-inventry',
  templateUrl: './inventry.component.html',
  styleUrl: './inventry.component.css'
})
export class InventryComponent {

}
