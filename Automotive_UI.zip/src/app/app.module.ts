import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { VehicleDisplayComponent } from './vehicle-display/vehicle-display.component';
import { DealershipDiscoveryComponent } from './dealership-discovery/dealership-discovery.component';
import { PersonalisedShowcaseComponent } from './personalised-showcase/personalised-showcase.component';
import { PurchaseProcessComponent } from './purchase-process/purchase-process.component';
import { InventryManagementComponent } from './inventry-management/inventry-management.component';
import { InventryComponent } from './inventry/inventry.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    SignupComponent,
    DashboardComponent,
    VehicleDisplayComponent,
    DealershipDiscoveryComponent,
    PersonalisedShowcaseComponent,
    PurchaseProcessComponent,
    InventryManagementComponent,
    InventryComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
