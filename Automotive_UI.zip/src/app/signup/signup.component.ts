import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrl: './signup.component.css'
})
export class SignupComponent implements OnInit {
    constructor(public authService: any) {}
    
    public user = {
        email : '',
        password : ''
    };
  
    ngOnInit() {
      this.authService.logout();    
  }

}
