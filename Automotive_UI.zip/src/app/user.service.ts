import { Injectable, OnInit } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserService implements OnInit {

  constructor() { }
  ngOnInit(): void {
    console.log("User Service Initialized");
  }
  
  private user = {name:"", email:""}; 
  }

