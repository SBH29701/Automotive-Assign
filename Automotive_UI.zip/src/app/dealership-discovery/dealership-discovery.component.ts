import { Component } from '@angular/core';

@Component({
  selector: 'app-dealership-discovery',
  templateUrl: './dealership-discovery.component.html',
  styleUrl: './dealership-discovery.component.css'
})
export class DealershipDiscoveryComponent {

}
