import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DealershipDiscoveryComponent } from './dealership-discovery.component';

describe('DealershipDiscoveryComponent', () => {
  let component: DealershipDiscoveryComponent;
  let fixture: ComponentFixture<DealershipDiscoveryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [DealershipDiscoveryComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(DealershipDiscoveryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
