package com.hbs.automotive;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutomotiveApplicationTests {

	@Test
	void contextLoads() {
	}

}
