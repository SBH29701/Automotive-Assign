package com.hbs.automotive;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AutomotiveApplication {

	public static void main(String[] args) {
		SpringApplication.run(AutomotiveApplication.class, args);
	}

}
