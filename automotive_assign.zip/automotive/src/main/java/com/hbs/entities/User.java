package com.hbs.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class User {
   @Id
	private int user_id;
	private String user_email;
	private String user_location;
	private String user_info;
	private String password;
	private String vechicle_info;
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public String getUser_email() {
		return user_email;
	}
	public void setUser_email(String user_email) {
		this.user_email = user_email;
	}
	public String getUser_location() {
		return user_location;
	}
	public void setUser_location(String user_location) {
		this.user_location = user_location;
	}
	public String getUser_info() {
		return user_info;
	}
	public void setUser_info(String user_info) {
		this.user_info = user_info;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getVechicle_info() {
		return vechicle_info;
	}
	public void setVechicle_info(String vechicle_info) {
		this.vechicle_info = vechicle_info;
	}

}
