package com.hbs.entities;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
@Entity
@Table(name="Cars")
public class Cars {
   @Id
   @GeneratedValue(strategy = GenerationType.IDENTITY)
   private int car_id;
   
   @Column(name="type", nullable = false)   
   private String type;
   
   @Column(name="name")   
   private String name;
	
   @Column(name="model")
   private String  model;
   
   @Column(name="car_info")
   private String car_info;
   
   @OneToOne(cascade = CascadeType.ALL, mappedBy = "Cars")
   private Sold_Vehicles sold_vehicles;
	
   public int getCar_id() {
		return car_id;
	}
	public void setCar_id(int car_id) {
		this.car_id = car_id;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getCar_info() {
		return car_info;
	}
	public void setCar_info(String car_info) {
		this.car_info = car_info;
	}
	public Sold_Vehicles getSold_vehicles() {
		return sold_vehicles;
	}
	public void setSold_vehicles(Sold_Vehicles sold_vehicles) {
		this.sold_vehicles = sold_vehicles;
	}

}
