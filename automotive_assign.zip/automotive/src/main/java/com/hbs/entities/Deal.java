package com.hbs.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
@Entity(name="Deal")
public class Deal {
   @Id
	  private int  deal_id;
	  private int car_id;
	  private String deal_info;
	
    public int getDeal_id() {
		return deal_id;
	}
	public void setDeal_id(int deal_id) {
		this.deal_id = deal_id;
	}
	public int getCar_id() {
		return car_id;
	}
	public void setCar_id(int car_id) {
		this.car_id = car_id;
	}
	public String getDeal_info() {
		return deal_info;
	}
	public void setDeal_info(String deal_info) {
		this.deal_info = deal_info;
	}

}
