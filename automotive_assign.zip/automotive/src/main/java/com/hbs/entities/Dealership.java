package com.hbs.entities;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
@Entity
@Table(name="Dealership_info")
public class Dealership {
   @Id
    private int dealership_id;
    private String dealership_name;
	private String dealership_email;
	private String password;
	private String dealership_location;
	private String dealership_info;
	private String cars;
	private String deals;
	private String sold_vehicles;
	
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name="dealership_id")
	private List<Cars> car = new ArrayList<Cars>();
	
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name="dealership_id")
	private List<Deal> deals2 = new ArrayList<Deal>();
	
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name="dealership_id")
	private List<Sold_Vehicles> Sold_vehicles = new ArrayList<Sold_Vehicles>();
	
	public int getDealership_id() {
		return dealership_id;
	}
	public void setDealership_id(int dealership_id) {
		this.dealership_id = dealership_id;
	}
	public String getDealership_name() {
		return dealership_name;
	}
	public void setDealership_name(String dealership_name) {
		this.dealership_name = dealership_name;
	}
	public String getDealership_email() {
		return dealership_email;
	}
	public void setDealership_email(String dealership_email) {
		this.dealership_email = dealership_email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getDealership_location() {
		return dealership_location;
	}
	public void setDealership_location(String dealership_location) {
		this.dealership_location = dealership_location;
	}
	public String getDealership_info() {
		return dealership_info;
	}
	public void setDealership_info(String dealership_info) {
		this.dealership_info = dealership_info;
	}
	public String getCars() {
		return cars;
	}
	public void setCars(String cars) {
		this.cars = cars;
	}
	public String getDeals() {
		return deals;
	}
	public void setDeals(String deals) {
		this.deals = deals;
	}
	public String getSold_vehicles() {
		return sold_vehicles;
	}
	public void setSold_vehicles(String sold_vehicles) {
		this.sold_vehicles = sold_vehicles;
	}
	public List<Cars> getCar() {
		return car;
	}
	public void setCar(List<Cars> car) {
		this.car = car;
	}
	public List<Deal> getDeals2() {
		return deals2;
	}
	public void setDeals2(List<Deal> deals2) {
		this.deals2 = deals2;
	}
	public void setSold_vehicles(List<Sold_Vehicles> sold_vehicles) {
		Sold_vehicles = sold_vehicles;
	}

}
