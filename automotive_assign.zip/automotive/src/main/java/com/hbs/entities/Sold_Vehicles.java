package com.hbs.entities;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;

@Entity
public class Sold_Vehicles {
    @Id    
	 private int  vehicle_id;
	 
	 private String vehicle_info;
	 
	 private int car_id;
	 
	 @OneToOne(cascade = CascadeType.ALL)
	 @JoinColumn(name="fk_cars")
	 private Cars cars;
	 
	public int getVehicle_id() {
		return vehicle_id;
	}
	public void setVehicle_id(int vehicle_id) {
		this.vehicle_id = vehicle_id;
	}
	public int getCar_id() {
		return car_id;
	}
	public void setCar_id(int car_id) {
		this.car_id = car_id;
	}
	public String getVehicle_info() {
		return vehicle_info;
	}
	public void setVehicle_info(String vehicle_info) {
		this.vehicle_info = vehicle_info;
	}
	public Cars getCars() {
		return cars;
	}
	public void setCars(Cars cars) {
		this.cars = cars;
	}


}
