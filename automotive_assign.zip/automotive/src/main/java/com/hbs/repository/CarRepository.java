package com.hbs.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hbs.entities.Cars;

public interface CarRepository extends JpaRepository<Cars, Integer> {

}
