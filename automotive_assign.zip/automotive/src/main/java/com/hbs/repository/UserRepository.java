package com.hbs.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hbs.entities.User;

public interface UserRepository extends JpaRepository<User, Integer>{

}
